/* ═══════════════════════════════════════════════════════════════════
   تـدّبير — PWA Install Prompt + UI behaviors
   ───────────────────────────────────────────────────────────────────
   هذا الملف يحتوي على:
     1. PWAInstall    — سلوك زر "ثبّت التطبيق" + iOS modal
     2. setupSectionLabel — تحديث label الـ section الحالي
     3. tierMarquee   — drag/swipe على الـ marquee

   ⚠️ Bootstrap (init للتطبيق) انتقل إلى 05-bootstrap.js
═══════════════════════════════════════════════════════════════════ */

var PWAInstall = (() => {
  let deferredPrompt = null;
  let banner, btn, dismiss, iosModal, iosBackdrop, iosClose, iosGotIt;

  // Check if iOS
  function isIOS() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  }

  // Check if already installed (standalone mode)
  function isStandalone() {
    return window.matchMedia('(display-mode: standalone)').matches 
        || window.navigator.standalone === true;
  }

  // Check if dismissed recently (within 7 days)
  function isDismissedRecently() {
    // 🔧 STORAGE FIX: Storage module مع fallback
    const dismissed = (window.Storage?.load('pwa_install_dismissed', null)) ?? localStorage.getItem('pwa_install_dismissed');
    if (!dismissed) return false;
    const days = (Date.now() - parseInt(dismissed)) / (1000 * 60 * 60 * 24);
    return days < 7;
  }

  function init() {
    banner = document.getElementById('pwaInstallBanner');
    btn = document.getElementById('pwaInstallBtn');
    dismiss = document.getElementById('pwaInstallDismiss');
    iosModal = document.getElementById('pwaIosModal');
    iosBackdrop = document.getElementById('pwaIosBackdrop');
    iosClose = document.getElementById('pwaIosClose');
    iosGotIt = document.getElementById('pwaIosGotIt');

    if (!banner) return;

    // Don't show if already installed
    if (isStandalone()) {
      banner.style.display = 'none';
      return;
    }

    // Don't show if dismissed recently
    if (isDismissedRecently()) {
      banner.style.display = 'none';
      return;
    }

    // iOS - Show banner with iOS instructions
    if (isIOS()) {
      setTimeout(() => showBanner(), 5000);
    }

    // Listen for beforeinstallprompt (Chrome, Edge, Android)
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      setTimeout(() => showBanner(), 3000);
    });

    // Listen for appinstalled
    window.addEventListener('appinstalled', () => {
      hideBanner();
      deferredPrompt = null;
      if (window.Toast?.show) {
        window.Toast.show('🎉 تم ثبّت التطبيق بنجاح!', 'ok');
      }
    });

    // Button handlers
    if (btn) btn.addEventListener('click', handleInstall);
    if (dismiss) dismiss.addEventListener('click', handleDismiss);
    if (iosClose) iosClose.addEventListener('click', hideIosModal);
    if (iosBackdrop) iosBackdrop.addEventListener('click', hideIosModal);
    if (iosGotIt) iosGotIt.addEventListener('click', hideIosModal);
  }

  function showBanner() {
    if (!banner || isStandalone() || isDismissedRecently()) return;
    banner.style.display = 'flex';
    requestAnimationFrame(() => banner.classList.add('show'));
  }

  function hideBanner() {
    if (!banner) return;
    banner.classList.remove('show');
    setTimeout(() => {
      banner.style.display = 'none';
    }, 500);
  }

  async function handleInstall() {
    // iOS - Show instructions modal
    if (isIOS()) {
      showIosModal();
      return;
    }

    // Android/Chrome - Use native prompt
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      
      if (choiceResult.outcome === 'accepted') {
        if (window.Toast?.show) {
          window.Toast.show('⏳ جارٍ التثبيت...', 'ok');
        }
      }
      
      deferredPrompt = null;
      hideBanner();
    } else {
      // Fallback - show instructions
      if (window.Toast?.show) {
        window.Toast.show('ℹ️ استخدم قائمة المتصفح لثبّت التطبيق', 'warn');
      }
    }
  }

  function handleDismiss() {
    // 🔧 STORAGE FIX: Storage module مع fallback
    if (window.Storage) window.Storage.save('pwa_install_dismissed', Date.now().toString());
    else localStorage.setItem('pwa_install_dismissed', Date.now().toString());
    hideBanner();
  }

  function showIosModal() {
    if (!iosModal) return;
    iosModal.style.display = 'flex';
    requestAnimationFrame(() => iosModal.classList.add('show'));
  }

  function hideIosModal() {
    if (!iosModal) return;
    iosModal.classList.remove('show');
    setTimeout(() => {
      iosModal.style.display = 'none';
    }, 300);
    hideBanner();
    // Mark as shown
    if (window.Storage) window.Storage.save('pwa_install_dismissed', Date.now().toString());
    else localStorage.setItem('pwa_install_dismissed', Date.now().toString());
  }

  // Manual trigger (can be called from anywhere)
  function forceShow() {
    if (window.Storage) window.Storage.remove('pwa_install_dismissed');
    else localStorage.removeItem('pwa_install_dismissed');
    if (isIOS()) {
      showIosModal();
    } else if (deferredPrompt) {
      handleInstall();
    } else {
      if (window.Toast?.show) {
        window.Toast.show('ℹ️ التطبيق مثبّت أو غير قابل للتثبيت في متصفحك', 'warn');
      }
    }
  }

  // Initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return {
    init,
    showBanner,
    hideBanner,
    forceShow,
    isStandalone,
    isIOS
  };
})();

window.PWAInstall = PWAInstall;

// ═══ Hook into auth success — يربط البصمة بالحساب بعد نجاح تسجيل الدخول ═══
// 🔒 SECURITY FIX: لا نخزّن كلمة السر بعد الآن (كانت بنص واضح في localStorage).
// Firebase يحفظ جلسة المستخدم في IndexedDB تلقائياً (LOCAL persistence)،
// فالبصمة دورها يصير "تأكيد هوية" قبل فتح التطبيق، مش إعادة تسجيل دخول.
(function hookAuthSuccess() {
  let lastAuthState = null;
  setInterval(() => {
    try {
      const user = window.Social?._state?.user;
      if (user && user.email && user.email !== lastAuthState) {
        lastAuthState = user.email;

        setTimeout(async () => {
          const supported = await BiometricAuth.isSupported();
          const hasRegistered = BiometricAuth.hasRegisteredCredential();
          // 🔧 STORAGE FIX: Storage module مع fallback
          const dismissed = (window.Storage?.load('biometric_dismissed', null)) ?? localStorage.getItem('biometric_dismissed');
          const dismissedRecently = dismissed && (Date.now() - parseInt(dismissed)) < 7 * 24 * 60 * 60 * 1000;

          if (supported && !hasRegistered && !dismissedRecently) {
            setTimeout(() => {
              const profile = window.Social?._state?.profile;
              const displayName = profile?.displayName || user.email.split('@')[0];

              // ⚠️ تم حذف تخزين كلمة السر بنص واضح
              // Firebase auth.currentUser سيبقى متاح عبر الجلسة المخزنة في IndexedDB
              // البصمة ستتحقق فقط من هوية المستخدم محلياً قبل فتح الواجهة

              BiometricAuth.showSetupPrompt(user.email, displayName, () => {
                // البصمة سُجّلت بنجاح — لا حاجة لحفظ كلمة السر
              });
            }, 3000);
          }
        }, 1000);
      }
    } catch (e) { if (window.Logger) Logger.warn('PWAInstall', e?.message); }
  }, 2000);
})();

// Override social-chats action to use dedicated page

// Initialize when DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => Sidebar.init());
} else {
  Sidebar.init();
}

window.Sidebar = Sidebar;


(function setupSectionLabel() {
  const sectionNames = {
    home: '🏠 الرئيسية',
    money: '💰 فلوسي',
    'money:monthly': '💰 الشهر الحالي',
    'money:yearly': '📅 تقرير السنة',
    social: '👥 اجتماعي',
    profile: '👤 ملفي',
    'profile:achievements': '🏆 إنجازاتي',
    'profile:settings': '⚙️ الإعدادات'
  };

  function updateSectionLabel() {
    try {
      const label = document.getElementById('currentSectionLabel');
      if (!label) return;

      const tab = window.App?.store?.get('tab') || 'home';
      const subTab = window.App?.store?.get('subTab');
      const key = subTab && (tab === 'money' || tab === 'profile') ? `${tab}:${subTab}` : tab;
      
      const name = sectionNames[key] || sectionNames[tab] || '🏠 الرئيسية';
      
      if (label.textContent !== name) {
        label.classList.remove('show');
        setTimeout(() => {
          label.textContent = name;
          label.classList.add('show');
        }, 150);
      } else {
        label.classList.add('show');
      }
    } catch (e) { if (window.Logger) Logger.warn('PWAInstall', e?.message); }
  }

  // Initial
  setTimeout(updateSectionLabel, 500);

  // Watch for tab changes
  if (window.App?.store) {
    const originalSet = window.App.store.set.bind(window.App.store);
    window.App.store.set = function(key, value) {
      const result = originalSet(key, value);
      if (key === 'tab' || key === 'subTab') {
        setTimeout(updateSectionLabel, 50);
      }
      return result;
    };
  }

  // Update on clicks
  document.addEventListener('click', (e) => {
    if (e.target.closest('.sub-nav-btn, .sidebar-item, .tab-btn')) {
      setTimeout(updateSectionLabel, 100);
    }
  });

  // Update periodically as safety net
  setInterval(updateSectionLabel, 3000);
})();



(function tierMarquee() {
  function setup() {
    const wrap = document.getElementById('tierMarquee');
    if (!wrap) return;
    const track = wrap.querySelector('.tier-marquee-track');
    if (!track) return;

    let isDown = false;
    let startX = 0;
    let scrollLeft = 0;
    let manualOffset = 0;
    let resumeTimer = null;

    function pause() {
      wrap.classList.add('paused');
      // Capture current animated position so dragging starts from where it visually is
      const computedTransform = getComputedStyle(track).transform;
      track.style.animation = 'none';
      track.style.transform = computedTransform === 'none' ? 'translateX(0)' : computedTransform;
    }

    function resume() {
      // After a delay, hand control back to the CSS animation
      track.style.transform = '';
      track.style.animation = '';
      wrap.classList.remove('paused');
    }

    function getX(e) {
      return e.touches ? e.touches[0].clientX : e.clientX;
    }

    function onDown(e) {
      isDown = true;
      pause();
      clearTimeout(resumeTimer);
      const matrix = new DOMMatrix(getComputedStyle(track).transform);
      manualOffset = matrix.m41;
      startX = getX(e);
      track.style.cursor = 'grabbing';
    }

    function onMove(e) {
      if (!isDown) return;
      const x = getX(e);
      const delta = x - startX;
      track.style.transform = `translateX(${manualOffset + delta}px)`;
      if (e.cancelable && e.touches) e.preventDefault();
    }

    function onUp() {
      if (!isDown) return;
      isDown = false;
      track.style.cursor = '';
      // Resume animation after a short pause
      resumeTimer = setTimeout(resume, 1800);
    }

    track.style.cursor = 'grab';

    wrap.addEventListener('mousedown', onDown);
    wrap.addEventListener('touchstart', onDown, { passive: true });
    document.addEventListener('mousemove', onMove);
    wrap.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('mouseup', onUp);
    wrap.addEventListener('touchend', onUp);
    wrap.addEventListener('touchcancel', onUp);

    // Pause on hover (desktop) — already in CSS but keep here for parity
    wrap.addEventListener('mouseenter', () => {
      if (!isDown) clearTimeout(resumeTimer);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setup);
  } else {
    setup();
  }
})();
